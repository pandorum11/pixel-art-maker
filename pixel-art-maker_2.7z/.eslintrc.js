module.exports = {
  extends: [
    'kmcgrady/browser',
    'kmcgrady/es6'
  ]
};